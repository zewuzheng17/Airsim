import airgym
import gym
import torch
import numpy as np


class Actor_critic():
    pass

class Policy_net():
    pass

class Value_net():
    pass

class Do_training():
    pass

class Replay_buffer():
    pass


## conda install pytorch torchvision torchaudio cudatoolkit=11.3 -c pytorch